# Vtu-sgpa-calculator


This is a mobile application created using Android Studio. This Application will calculate CGPA and SGPA using thee rsult provided by the VTU. I include it for 2015,2017 and 2018 batch students.

### Tools/Technology.
1. Java
2. Android Studio
3. XML

If you like this work ⭐ repository.
